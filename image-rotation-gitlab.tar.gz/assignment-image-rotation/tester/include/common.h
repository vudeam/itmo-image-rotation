#pragma once

#define EXECUTABLE_NAME "image-transformer"

